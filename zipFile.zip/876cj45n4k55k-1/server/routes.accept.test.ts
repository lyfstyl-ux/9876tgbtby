import { describe, it, expect, vi, beforeEach } from 'vitest';
import request from 'supertest';
import express from 'express';
import { createServer } from 'http';
import { registerRoutes } from './routes';
import * as storageModule from './storage';

async function setupApp() {
  const app = express();
  const http = createServer(app);
  app.use(express.json());
  await registerRoutes(http, app);
  return app;
}

describe('accept/decline routes', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('accept returns 404 if challenge not found', async () => {
    const app = await setupApp();
    const spyGet = vi.spyOn(storageModule.storage as any, 'getChallenge').mockResolvedValue(undefined);
    const res = await request(app).post('/api/challenges/999/accept').send({ txHash: '0xabc' });
    expect(res.status).toBe(404);
    spyGet.mockRestore();
  });

  it('accept updates challenge to matched', async () => {
    const app = await setupApp();
    const fakeChallenge = { id: 123, challenger: '@a', opponent: '@b', name: 'test', amount: 1000, currency: 'USDC', status: 'active' } as any;
    const spyGet = vi.spyOn(storageModule.storage as any, 'getChallenge').mockResolvedValue(fakeChallenge as any);
    const spyUpdate = vi.spyOn(storageModule.storage as any, 'updateChallenge').mockResolvedValue({ ...fakeChallenge, status: 'matched', matchedTxHash: '0xabc' } as any);

    const res = await request(app).post('/api/challenges/123/accept').send({ txHash: '0xabc', escrowId: 1, tokenAddress: '0xTOKEN', opponentAddress: '@b' });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('matched');
    expect(res.body.matchedTxHash).toBe('0xabc');

    spyGet.mockRestore();
    spyUpdate.mockRestore();
  });

  it('decline updates challenge to declined', async () => {
    const app = await setupApp();
    const fakeChallenge = { id: 456, challenger: '@a', opponent: '@b', name: 'test2', amount: 500 } as any;
    const spyGet = vi.spyOn(storageModule.storage as any, 'getChallenge').mockResolvedValue(fakeChallenge as any);
    const spyUpdate = vi.spyOn(storageModule.storage as any, 'updateChallenge').mockResolvedValue({ ...fakeChallenge, status: 'declined' } as any);

    const res = await request(app).post('/api/challenges/456/decline').send({ reason: 'nope' });
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('declined');

    spyGet.mockRestore();
    spyUpdate.mockRestore();
  });
});